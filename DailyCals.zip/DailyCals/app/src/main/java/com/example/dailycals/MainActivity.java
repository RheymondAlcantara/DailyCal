package com.example.dailycals;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    ImageButton btnAddBreakfast, btnAddLunch, btnAddDinner, btnAddSnacks;
    Button btnBMIResult, btnTrackCalorie, btnHistory, btnLogout, btnAddActivity;
    TextView tvTotal, tvCaloriesEaten, tvCaloriesBurned, tvBMIStatus;
    DatabaseHelper db;
    int userId;
    SharedPreferences sp;

    private final Map<String, TextView> mealProgressViews = new HashMap<>();
    private final Map<Integer, String> requestCodeToMealType = new HashMap<Integer, String>() {{
        put(1, "Breakfast");
        put(2, "Lunch");
        put(3, "Dinner");
        put(4, "Snacks");
    }};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DatabaseHelper(this);
        sp = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        userId = sp.getInt("user_id", -1);

        tvTotal = findViewById(R.id.tvTotal);
        tvCaloriesEaten = findViewById(R.id.tvCaloriesEaten);
        tvCaloriesBurned = findViewById(R.id.tvCaloriesBurned);
        tvBMIStatus = findViewById(R.id.tvBMIStatus);

        btnBMIResult = findViewById(R.id.btnBMIResult);
        btnTrackCalorie = findViewById(R.id.btnTrackCalorie);
        btnHistory = findViewById(R.id.btnHistory);
        btnLogout = findViewById(R.id.btnLogout);
        btnAddActivity = findViewById(R.id.btnAddActivity);

        setupMealCard(R.id.breakfastSection, "Breakfast", R.drawable.ic_breakfast, 1);
        setupMealCard(R.id.lunchSection, "Lunch", R.drawable.ic_lunch, 2);
        setupMealCard(R.id.dinnerSection, "Dinner", R.drawable.ic_dinner, 3);
        setupMealCard(R.id.snacksSection, "Snacks", R.drawable.ic_snacks, 4);

        btnBMIResult.setOnClickListener(v -> startActivity(new Intent(this, BMIActivity.class)));
        btnTrackCalorie.setOnClickListener(v -> startActivity(new Intent(this, TrackCalorieActivity.class)));
        btnHistory.setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
        btnAddActivity.setOnClickListener(v -> startActivity(new Intent(this, ActivityAddActivity.class)));

        btnLogout.setOnClickListener(v -> {
            sp.edit().remove("user_id").apply();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        updateDashboard();
    }

    private void setupMealCard(int sectionId, String label, int iconResId, int requestCode) {
        ViewGroup section = findViewById(sectionId);
        TextView title = section.findViewById(R.id.tvMealTitle);
        ImageView icon = section.findViewById(R.id.ivMealIcon);
        ImageButton btnAdd = section.findViewById(R.id.btnAddMeal);
        TextView progress = section.findViewById(R.id.tvMealProgress);

        title.setText(label);
        icon.setImageResource(iconResId);
        mealProgressViews.put(label, progress);

        btnAdd.setOnClickListener(v -> {
            Toast.makeText(this, "Add food to " + label, Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MainActivity.this, SavedFoodsActivity.class);
            intent.putExtra("mealType", label);
            startActivityForResult(intent, requestCode);
        });

        switch (label) {
            case "Breakfast": btnAddBreakfast = btnAdd; break;
            case "Lunch": btnAddLunch = btnAdd; break;
            case "Dinner": btnAddDinner = btnAdd; break;
            case "Snacks": btnAddSnacks = btnAdd; break;
        }
    }

    private void updateDashboard() {
        int totalCalories = db.getTodayTotalCalories(userId);
        int burned = db.getTodayCaloriesBurned(userId);
        String bmi = db.getLatestBMI(userId);

        tvTotal.setText("Today's Calories: " + totalCalories);
        tvCaloriesEaten.setText("Calories Eaten: " + totalCalories + " kcal");
        tvCaloriesBurned.setText("Calories Burned: " + burned + " kcal");
        tvBMIStatus.setText("BMI: " + bmi);

        // Optional: Update per-meal kcal totals here if you support that tracking.
        for (String meal : mealProgressViews.keySet()) {
            updateMealProgress(meal, 0); // Default 0 or query if stored separately
        }
    }

    private void updateMealProgress(String meal, int addedCalories) {
        TextView view = mealProgressViews.get(meal);
        if (view != null) {
            String current = view.getText().toString(); // e.g., "120 / 700 kcal"
            int currentCals = 0;
            try {
                currentCals = Integer.parseInt(current.split("/")[0].trim());
            } catch (Exception ignored) {}

            int updated = currentCals + addedCalories;
            view.setText(updated + " / 700 kcal");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            String food = data.getStringExtra("food");
            int calories = data.getIntExtra("calories", 0);
            int carbs = data.getIntExtra("carbs", 0);
            int protein = data.getIntExtra("protein", 0);
            int fat = data.getIntExtra("fat", 0);
            String mealType = data.getStringExtra("mealType");

            db.addFullCalorieEntry(userId, food, calories, carbs, protein, fat);
            Toast.makeText(this, food + " added to " + mealType, Toast.LENGTH_SHORT).show();

            updateMealProgress(mealType, calories);
            updateDashboard();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateDashboard();
    }
}
