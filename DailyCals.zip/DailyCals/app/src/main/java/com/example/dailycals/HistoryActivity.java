package com.example.dailycals;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class HistoryActivity extends AppCompatActivity {

    TextView tvHistory;
    DatabaseHelper db;
    int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        db = new DatabaseHelper(this);
        tvHistory = findViewById(R.id.tvHistory);

        SharedPreferences sp = getSharedPreferences("MyPrefs", MODE_PRIVATE);
        userId = sp.getInt("user_id", -1);

        Cursor cursor = db.getHistory(userId);
        StringBuilder history = new StringBuilder();

        if (cursor != null && cursor.moveToFirst()) {
            do {
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));
                String food = cursor.getString(cursor.getColumnIndexOrThrow("food"));
                int calories = cursor.getInt(cursor.getColumnIndexOrThrow("calories"));

                history.append("🗓 ").append(date)
                        .append(" - 🍽 ").append(food)
                        .append(": 🔥 ").append(calories).append(" cal\n");

            } while (cursor.moveToNext());
            cursor.close();
        } else {
            history.append("No history available.");
        }

        tvHistory.setText(history.toString());
    }
}
