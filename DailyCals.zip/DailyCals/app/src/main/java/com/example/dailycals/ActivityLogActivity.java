package com.example.dailycals;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class ActivityLogActivity extends AppCompatActivity {

    ListView listViewActivities;
    DatabaseHelper dbHelper;
    int userId; // You should get this from Intent or Session

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log); // Make sure your layout file is named activity_log.xml

        dbHelper = new DatabaseHelper(this);
        listViewActivities = findViewById(R.id.listViewActivities); // Ensure ID exists in XML

        // TEMP: For demo; get actual user ID from Login or Intent
        userId = getIntent().getIntExtra("user_id", -1);
        if (userId == -1) {
            finish();
            return;
        }

        loadActivityLog();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadActivityLog();  // Reload data when returning here
    }
    private void loadActivityLog() {
        Cursor cursor = dbHelper.getActivityLog(userId);
        ArrayList<String> activityList = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                String type = cursor.getString(cursor.getColumnIndexOrThrow("activity_type"));
                String duration = cursor.getString(cursor.getColumnIndexOrThrow("duration")); // now String
                int calories = cursor.getInt(cursor.getColumnIndexOrThrow("calories_burned"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("date"));

                activityList.add(date + " - " + type + ": " + duration + ", -" + calories + " kcal");
            } while (cursor.moveToNext());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, activityList);
        listViewActivities.setAdapter(adapter);
    }
}
